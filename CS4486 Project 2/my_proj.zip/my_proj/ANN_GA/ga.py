import numpy as np
import operator
from model import ANN

def init_pop(popSize, layer_sizes):
    population = []
    for i in range(popSize):
        population.append(ANN(layer_sizes))
    return np.array(population)

def sort_pop(population, data, label, dropP):
    
    fitness = {}
    for i in range(len(population)):
        loss, acc, pred = population[i].forward(data, label, 'ReLU', dropP)
        fitness[i] = acc
        
    sorted_fitness = sorted(fitness.items(), key = operator.itemgetter(1), reverse = True)
    fitness = [fit for idx, fit in sorted_fitness]
    sorted_pop = population[[idx for idx, fit in sorted_fitness]]
    return fitness, sorted_pop

def next_pop(population, cr, mr, elitePer, fitness, data, label, dropP):
    popSize = len(population)
    eliteSize = int(elitePer * popSize)
    
    # selection
    if fitness == None:
        score,  sorted_pop = sort_pop(population, data, label, dropP)
    else:
        score = fitness
        sorted_pop = population
        
    # normalization
    score = score/np.sum(score)
    
    # preserve elite parents
    elite = sorted_pop[:eliteSize]
    
    # crossover
    children = []
    for p1 in sorted_pop:
        p2 = sorted_pop[np.random.choice(range(len(sorted_pop)), p = score)]
        if p1 in elite:
            # preserve elite, but also allow it to crossover
            children.append(p1.crossover(p2, 1))
        else:
            children.append(p1.crossover(p2, cr))
    
    # mutation
    for i in range(len(children)):
        children[i].mutation(mr)

    children = np.hstack((children, elite))
    fitness, children = sort_pop(children, data, label, dropP)
    
    return fitness[:popSize], children[:popSize]
    
    