import numpy as np
import random, copy

# helper functions
def sigmoid(x):
    return 1.0 / (1+np.exp(-x))
def tanh(x):
    return np.tanh(x)
def Gaussian(x):
    return np.exp(-x**2)
def ReLU(x):
    return np.where(x>0, x, 0)
def dropout(x, p):
    mask = (np.random.uniform(0,1,x.shape)<=p)/p
    return x*mask

# Neural Network Individual
class ANN(object):
    
    def __init__(self, layer_sizes, Weights = None):
        self.layer_sizes = layer_sizes
        self.Ws = np.array([None for x in range(len(layer_sizes) - 1)])
        if Weights != None:
            self.Ws = Weights
        else: 
            for i in range(len(layer_sizes)-1):
                self.Ws[i] = np.random.uniform(-1, 1, (layer_sizes[i]+1, layer_sizes[i+1]))
    
    def forward(self, data, label, activation = "sigmoid", dropP = 1):
        out = data
        for W in self.Ws:
            # append a bias row
            out = np.hstack( [np.ones( (out.shape[0], 1) ), out] )
            
            # dropout
            out = dropout(out, dropP)
            
            # Linear combination 
            out = out.dot(W)
            
            # Activation
            if activation == 'sigmoid':
                out = sigmoid(out)
            elif activation == 'tanh':
                out = tanh(out)
            elif activation == 'Gaussian':
                out = Gaussian(out)
            elif activation == 'ReLU':
                out = ReLU(out)
        # MSE expectation on the training set
        loss = 0.5*np.sum((out-label)**2)/data.shape[0]
        
        pred = np.argmax(out, axis=1)
        truth = np.argmax(label, axis=1)
        accuracy = np.mean(pred==truth)
        return loss, accuracy, pred
    
    def mutation(self, mutationRate):
        if random.random() < mutationRate:
            for i in range(self.Ws.shape[0]):
                idx = np.random.randint(2, size = self.Ws[i].shape)
                randnum = np.random.uniform(-1,1)
                self.Ws[i][idx==1] = randnum
    
    def crossover(self, other_net, crossoverRate):
        parent1 = self.Ws
        parent2 = other_net.Ws
        
        if random.random() < crossoverRate:
            child = np.array([None for i in range(parent1.shape[0])])
            # for each weight matrix
            for i in range(parent1.shape[0]):
                # tmp = [p1_mat, p2_mat]
                tmp = np.array([parent1[i], parent2[i]])
                # each column correspond to a value as zero or one
                idx = np.random.randint(2, size=tmp.shape[2])
                # for each column, select one from parent1 and parent2 randomly
                child[i] = tmp[idx,:,range(tmp.shape[2])].T
            child_net = ANN(self.layer_sizes, Weights = child)
            return child_net
        else:
            return copy.deepcopy(self)
    
    