import numpy as np

def split(data, label, num):
    idx = np.random.choice(data.shape[0], num, replace=False)
    data_train = data[idx]
    label_train = label[idx]
    data_test = data[[x for x in range(data.shape[0]) if x not in idx]]
    label_test = label[[x for x in range(data.shape[0]) if x not in idx]]
    return data_train, label_train, data_test, label_test